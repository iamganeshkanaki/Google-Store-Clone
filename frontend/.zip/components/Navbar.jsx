import React from 'react'
import Image from 'next/image'
import styles from '.././styles/Navbar.module.scss'

const Navbar = () => {
  return (
    <div> 
    <div className={styles.Navbar_Container}>
    <div className={styles.Navbar_Container_Left}>
      <div  className={styles.Navbar_Container_Left_Image}> 
      <Image
      src="/Images/NavbarImages/googlelogo.png"
      width={22}
      height={22}
      />
      </div>

      <div className={styles.Navbar_Container_Left_Text}> 
      <h3> Phones </h3>
      <h3> Watch </h3>
      <h3> Earbuds </h3>
      <h3> Accessories </h3>
      </div>

    </div> 
    </div>
    </div>
  )
}

export default Navbar
