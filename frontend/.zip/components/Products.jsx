import React from "react";
import {Card, CardFooter, Image, Button} from "@nextui-org/react";
import styles from '.././styles/Products.module.scss'

const data = [
    {
      id: 1,
      image: 'Images/pixel 7a.png',
      text: 'Pixel 7a',
    },
    {
      id: 2,
      image: 'Images/pixel7pro.png',
      text: 'Pixel 7 Pro',
    },

    {
        id: 3,
        image: 'Images/pixel7.png',
        text: 'Pixel 7',
    },

    {
        id: 4,
        image: 'Images/pixel6a.png',
        text: 'Pixel 6a',
    },

    {
        id: 5,
        image: 'Images/nestaware.png',
        text: 'Nest Aware',
    },

    {
        id: 6,
        image: 'Images/ncam.png',
        text: 'Nest Cam',
    },

    {
        id: 7,
        image: 'Images/nestmini.png',
        text: 'Nest Mini',
    },

    {
        id: 8,
        image: 'Images/nestaudio.png',
        text: 'Nest Audio',
    },

    {
        id: 9,
        image: 'Images/pixel7acase.png',
        text: 'Pixel 7a Case',
    },
    // Add more objects as needed
  ];

export default function App() {
  return (
    <div> 
     <div style={{ display: 'flex', flexDirection: 'row', flexWrap:'wrap' }}>
    {data.map((item) => (
        <div key={item.id} style={{display:'flex', flexDirection:'row', flexWrap:'wrap'}} >

    <Card
     className={styles.Products_Container} 
    >
      <Image
        alt="Woman listing to music"
        height={300}
        src={item.image}
        width={300}
        
      />
      <CardFooter>
        <p >{item.text} </p> 
      </CardFooter>
    </Card>
    </div>
      ))}
      </div>
    </div>
  );
}
