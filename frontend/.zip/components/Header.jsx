import React from 'react'
import styles from '.././styles/Header.module.scss'

const Header = () => {
  return (
    <div>
      <div className={styles.Header_Container}> 
      <h3 className={styles.Header_Container_Welcome}> Welcome To The </h3>
      <h3 className={styles.Header_Container_Google}> Google Store </h3>
      </div>
    </div>
  )
}

export default Header
