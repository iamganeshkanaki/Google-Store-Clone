"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/scroll-into-view-if-needed";
exports.ids = ["vendor-chunks/scroll-into-view-if-needed"];
exports.modules = {

/***/ "(ssr)/./node_modules/scroll-into-view-if-needed/dist/index.js":
/*!***************************************************************!*\
  !*** ./node_modules/scroll-into-view-if-needed/dist/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ t)\n/* harmony export */ });\n/* harmony import */ var compute_scroll_into_view__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! compute-scroll-into-view */ \"(ssr)/./node_modules/compute-scroll-into-view/dist/index.js\");\nconst o=e=>!1===e?{block:\"end\",inline:\"nearest\"}:(e=>e===Object(e)&&0!==Object.keys(e).length)(e)?e:{block:\"start\",inline:\"nearest\"};function t(t,n){if(!t.isConnected||!(e=>{let o=e;for(;o&&o.parentNode;){if(o.parentNode===document)return!0;o=o.parentNode instanceof ShadowRoot?o.parentNode.host:o.parentNode}return!1})(t))return;if((e=>\"object\"==typeof e&&\"function\"==typeof e.behavior)(n))return n.behavior((0,compute_scroll_into_view__WEBPACK_IMPORTED_MODULE_0__.compute)(t,n));const r=\"boolean\"==typeof n||null==n?void 0:n.behavior;for(const{el:i,top:a,left:l}of (0,compute_scroll_into_view__WEBPACK_IMPORTED_MODULE_0__.compute)(t,o(n)))i.scroll({top:a,left:l,behavior:r})}//# sourceMappingURL=index.js.map\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvc2Nyb2xsLWludG8tdmlldy1pZi1uZWVkZWQvZGlzdC9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFtRCxtQkFBbUIsNkJBQTZCLHFEQUFxRCxnQ0FBZ0MsZ0JBQWdCLHlCQUF5QixRQUFRLEtBQUssZ0JBQWdCLEVBQUUsb0NBQW9DLG9FQUFvRSxTQUFTLFlBQVksK0VBQStFLGlFQUFDLE9BQU8sdURBQXVELFVBQVUsa0JBQWtCLEdBQUcsaUVBQUMsbUJBQW1CLHdCQUF3QixFQUF1QiIsInNvdXJjZXMiOlsid2VicGFjazovL2dvb2dsZS1zdG9yZS1jbG9uZS8uL25vZGVfbW9kdWxlcy9zY3JvbGwtaW50by12aWV3LWlmLW5lZWRlZC9kaXN0L2luZGV4LmpzPzhhMTYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0e2NvbXB1dGUgYXMgZX1mcm9tXCJjb21wdXRlLXNjcm9sbC1pbnRvLXZpZXdcIjtjb25zdCBvPWU9PiExPT09ZT97YmxvY2s6XCJlbmRcIixpbmxpbmU6XCJuZWFyZXN0XCJ9OihlPT5lPT09T2JqZWN0KGUpJiYwIT09T2JqZWN0LmtleXMoZSkubGVuZ3RoKShlKT9lOntibG9jazpcInN0YXJ0XCIsaW5saW5lOlwibmVhcmVzdFwifTtmdW5jdGlvbiB0KHQsbil7aWYoIXQuaXNDb25uZWN0ZWR8fCEoZT0+e2xldCBvPWU7Zm9yKDtvJiZvLnBhcmVudE5vZGU7KXtpZihvLnBhcmVudE5vZGU9PT1kb2N1bWVudClyZXR1cm4hMDtvPW8ucGFyZW50Tm9kZSBpbnN0YW5jZW9mIFNoYWRvd1Jvb3Q/by5wYXJlbnROb2RlLmhvc3Q6by5wYXJlbnROb2RlfXJldHVybiExfSkodCkpcmV0dXJuO2lmKChlPT5cIm9iamVjdFwiPT10eXBlb2YgZSYmXCJmdW5jdGlvblwiPT10eXBlb2YgZS5iZWhhdmlvcikobikpcmV0dXJuIG4uYmVoYXZpb3IoZSh0LG4pKTtjb25zdCByPVwiYm9vbGVhblwiPT10eXBlb2Ygbnx8bnVsbD09bj92b2lkIDA6bi5iZWhhdmlvcjtmb3IoY29uc3R7ZWw6aSx0b3A6YSxsZWZ0Omx9b2YgZSh0LG8obikpKWkuc2Nyb2xsKHt0b3A6YSxsZWZ0OmwsYmVoYXZpb3I6cn0pfWV4cG9ydHt0IGFzIGRlZmF1bHR9Oy8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcFxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/scroll-into-view-if-needed/dist/index.js\n");

/***/ })

};
;